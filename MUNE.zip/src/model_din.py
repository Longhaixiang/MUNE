# =========================================================================
# Copyright (C) 2021. Huawei Technologies Co., Ltd. All rights reserved.
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =========================================================================

from typing import List, Tuple, Dict, Any
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, get_linear_schedule_with_warmup
from .configuration_bert import BertConfig
from .unbert import UNBertModel
from transformers import AutoConfig, AutoModel, BertForMaskedLM
from fuxictr.pytorch.layers import MLP_Block, DIN_Attention

import numpy as np

class UserEmbedding(nn.Module):
    def __init__(self, hidden):
        super().__init__()
        self.W = nn.Linear(hidden, hidden)
        self.q = nn.Parameter(torch.randn(hidden))
    def forward(self, X):
        att = self.q * torch.tanh(self.W(X))
        att_weight = att.softmax(dim=-1)
        
        feature = torch.sum(X * att_weight, dim = 1)
        return feature

class UNBERT(nn.Module):
    def __init__(
        self,
        pretrained: str,
        level_sate: str = 'both',
        news_mode: str = 'nseg',
        max_len: int = None
    ) -> None:
        super(UNBERT, self).__init__()
        self._pretrained = pretrained
        self._level_state = level_sate
        self._news_mode = news_mode

        self._config = BertConfig.from_pretrained(self._pretrained)
        # self._config = BertForMaskedLM.from_pretrained(self._pretrained)
        # self._model = AutoModel.from_pretrained(self._pretrained)
        self._model = UNBertModel.from_pretrained(self._pretrained, config=self._config)

        # 2024
        self.din_attn = DIN_Attention(embedding_dim=768)
        self.mlp_block = MLP_Block(input_dim=768, output_dim=1, hidden_units=[512, 128, 64], hidden_activations="ReLU")
        self.user_encode = UserEmbedding(hidden=768)
        self.bin_dense = nn.Linear(35*768, 768)
        self.linear_transform = nn.Linear(768*2, 768)

        if self._level_state == 'both':
            self._dense = nn.Linear(self._config.hidden_size * 2, 2)
        else:
            self._dense = nn.Linear(self._config.hidden_size, 2)   # hidden, 2

        if self._news_mode == 'attention':
            assert max_len is not None
            self.att = nn.Sequential( 
                       nn.Linear(max_len * self._config.hidden_size, 128),
                       nn.Sigmoid(),
                       nn.Linear(128, max_len)
                       )
        else:
            self.att = None
        
    def min_max_normalize(self, tensor, new_min=-1, new_max=1):
            min_val = torch.min(tensor)
            max_val = torch.max(tensor)
            normalized_vector = (tensor - min_val) / (max_val - min_val) * (new_max - new_min) + new_min
            return normalized_vector
    
    def sclaed_tanh(self, x, a, b, c, d):
        return a * torch.tanh(b * x + c) + d
    
    def normalize(self, tensor, dim):
        mean = tensor.mean(dim=dim, keepdim=True)
        std = tensor.std(dim=dim, keepdim=True)
        normalized_tensor = (tensor - mean) / (std + 1e-8)
        return normalized_tensor
    
    def forward(self, 
                input_ids: torch.Tensor, 
                input_mask: torch.Tensor = None, 
                segment_ids: torch.Tensor = None,
                news_segment_ids: torch.Tensor = None,
                sentence_ids: torch.Tensor = None,
                sentence_mask: torch.Tensor = None,
                sentence_segment_ids: torch.Tensor = None
                ) -> Tuple[torch.Tensor, torch.Tensor]:
        output = self._model(input_ids, 
                             attention_mask = input_mask, 
                             token_type_ids = segment_ids,
                             news_segment_ids = news_segment_ids,
                             sentence_input = (sentence_ids, sentence_mask, sentence_segment_ids),
                             news_mode=self._news_mode,
                             att_mapping=self.att)  
        
        # type(output) = tuple len(output)=3
        # outputs = (sequence_output, sentence_output, pooled_output,) + encoder_outputs[1:]  
        word_hidden = output[0][:, 0, :]  # [1, 768]
        sentence_hidden = output[1][:, 0, :]  # [1, 768]
        word_hidden_hist = output[0]  #[1,300,768]
        sentence_hidden_hist = output[1] #[1,35,768]
        pooled_hidden = output[2]  #[1,768]

        # add din model (2024)

        hist_coding = torch.cat((word_hidden_hist, sentence_hidden_hist), dim=1)  #[1,335,768]
        user_coding = self.user_encode(hist_coding)  #[1,768] 用户特征信息embedding

        mask = hist_coding[:,:,0] != 0  # [1,300]
        bin_emb = self.din_attn(user_coding, hist_coding, mask) # [1, 768][1, 335, 768][1,335] / output:(1,768)

        # deeper bmm 得到相似特征权重
        bin_emb = bin_emb.unsqueeze(1)
        bin_emb_expand = bin_emb.expand(-1, 35, -1)
        cosine_sim = F.cosine_similarity(sentence_hidden_hist, bin_emb_expand, dim=-1)

        cosine_sim_expand = cosine_sim.unsqueeze(-1).expand_as(sentence_hidden_hist)
        weight_feature = sentence_hidden_hist * cosine_sim_expand  # [1,35,768]

        # add tach vector
        a = torch.mean(weight_feature, dim=1)
        a = torch.mean(a, dim=0)  # [768]
        deeper_score = self.sclaed_tanh(weight_feature, a, a/4, a/2, a/4) #[1,35,768]
        hidden = torch.cat([word_hidden, sentence_hidden], -1)  # [1,1536]

        ## 线性变换融合
        
        hidden_transformed = self.linear_transform(hidden)
        hidden_expand = hidden_transformed.unsqueeze(1).expand(-1,35,-1)
        deeper_emb = deeper_score + hidden_expand  #[1,35,768]

        # deeper_hidden = self.mlp_block(deeper_emb)
        deeper_hidden = self.bin_dense(deeper_emb.view(1, -1))
        
        if self._level_state == 'word':  ## word-level-model
            hidden = deeper_hidden
        elif self._level_state == 'news':  
            hidden = deeper_hidden       ## news-level-modle
        else:
            hidden = torch.cat([word_hidden, sentence_hidden], -1)  ## Eword + Enews
        score = self._dense(deeper_hidden).squeeze(-1)  # Linear(in_features=768, out_features=2, bias=True)
        return score  #[bs,2]  click predictor
